# Spectre -> Minecraft 1.21.4 (Fabric) — source port

Cach build:
1. Cai JDK 21. Mo thu muc nay bang IntelliJ (Gradle) hoac chay `gradle wrapper --gradle-version 8.12` roi `./gradlew build`.
2. File mod nam o `build/libs/spectre-*.jar` (khong lay file -sources).
3. Neu build loi: gui toan bo log loi cho AI/nguoi port de sua tiep.

TRANG THAI (trung thuc):
- Da doi tu dong: Identifier->ResourceLocation, GuiGraphicsExtractor->GuiGraphics, selected slot, ClickType,
  EntityType, package boat/projectile, Window.getWindow(), PacketAttacks (goi tan cong), bo Spear Swap,
  Nautilus/Happy Ghast. Cu phap toan bo qua javac.
- CHUA duoc bien dich that (khong co jar Minecraft luc port) => co the con loi symbol.
- Cac file con dung API render/input cua ban moi (Gizmo, GpuDevice, RenderPipeline, SubmitNode, RenderTypes,
  KeyEvent/MouseButtonEvent...) can viet lai bang RenderSystem/ShaderInstance/GuiGraphics cua 1.21.4:
  xem TODO_FILES.txt.
- ~150 mixin chua doi chieu target/method voi 1.21.4: loi mixin se hien luc vao game, sua theo log.
- spectre.mixins.json can loai bo mixin nao tro toi class khong ton tai o 1.21.4.
