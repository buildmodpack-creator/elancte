package com.example.client.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.spectre.client.module.impl.render.character.CharacterLayer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.world.entity.HumanoidArm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PlayerModel.class)
public abstract class MixinCharacterPlayerModel {
   @Inject(method = "translateToHand(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;Lnet/minecraft/world/entity/HumanoidArm;Lcom/mojang/blaze3d/vertex/PoseStack;)V", at = @At("HEAD"), cancellable = true)
   private void spectre$characterHand(PlayerRenderState state, HumanoidArm arm, PoseStack poseStack, CallbackInfo ci) {
      if (CharacterLayer.translateToHand((PlayerModel)(Object)this, state, arm, poseStack)) {
         ci.cancel();
      }
   }
}
