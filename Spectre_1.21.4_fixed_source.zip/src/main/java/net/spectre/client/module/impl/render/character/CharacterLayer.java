package net.spectre.client.module.impl.render.character;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.world.entity.HumanoidArm;

@Environment(EnvType.CLIENT)
public final class CharacterLayer extends RenderLayer<PlayerRenderState, PlayerModel> {
   public CharacterLayer(RenderLayerParent<PlayerRenderState, PlayerModel> parent) {
      super(parent);
   }

   public void submit(PoseStack poseStack, SubmitNodeCollector collector, int light, PlayerRenderState state, float yRot, float xRot) {
      WornCharacter worn = CharacterModule.worn(state);
      if (worn != null && (!state.isInvisible || !state.isInvisibleToPlayer)) {
         CharacterRenderer.submit(worn, this.getParentModel(), poseStack, collector, light, state);
      }
   }

   public static boolean firstPersonHand(PlayerModel model, PoseStack poseStack, SubmitNodeCollector collector, int light, ModelPart arm) {
      return CharacterRenderer.firstPersonHand(model, poseStack, collector, light, arm);
   }

   public static boolean translateToHand(PlayerModel model, PlayerRenderState state, HumanoidArm arm, PoseStack poseStack) {
      return CharacterRenderer.translateToHand(model, state, arm, poseStack);
   }
}
