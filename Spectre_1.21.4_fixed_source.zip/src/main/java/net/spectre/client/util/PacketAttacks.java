package net.spectre.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

/** 1.21.4 has no dedicated attack packet: attacks are ServerboundInteractPacket with the ATTACK action. */
@Environment(EnvType.CLIENT)
public final class PacketAttacks {
   private PacketAttacks() {
   }

   public static boolean isAttack(ServerboundInteractPacket packet) {
      boolean[] attack = new boolean[1];
      packet.dispatch(new ServerboundInteractPacket.Handler() {
         @Override
         public void onInteraction(InteractionHand hand) {
         }

         @Override
         public void onInteraction(InteractionHand hand, Vec3 location) {
         }

         @Override
         public void onAttack() {
            attack[0] = true;
         }
      });
      return attack[0];
   }
}
